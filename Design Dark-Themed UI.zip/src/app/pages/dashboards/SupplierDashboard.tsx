import { motion } from "motion/react";
import DashboardLayout from "../../components/DashboardLayout";
import StatsCard from "../../components/StatsCard";
import { Truck, Clock, CheckCircle2, AlertCircle } from "lucide-react";

const shipments = [
  {
    id: "SHP-001",
    status: "Dispatched",
    destination: "Warehouse A",
    eta: "2 hours",
    delay: null,
  },
  {
    id: "SHP-002",
    status: "In Transit",
    destination: "Warehouse B",
    eta: "5 hours",
    delay: "30 min delay",
  },
  {
    id: "SHP-003",
    status: "Delivered",
    destination: "Warehouse C",
    eta: "Completed",
    delay: null,
  },
  {
    id: "SHP-004",
    status: "In Transit",
    destination: "Distribution Center",
    eta: "3 hours",
    delay: null,
  },
];

const timeline = [
  { time: "08:00 AM", event: "Order Received", status: "completed" },
  { time: "09:30 AM", event: "Products Packed", status: "completed" },
  { time: "10:15 AM", event: "Dispatched from Warehouse", status: "completed" },
  { time: "12:00 PM", event: "In Transit", status: "active" },
  { time: "03:00 PM", event: "Expected Delivery", status: "pending" },
];

export default function SupplierDashboard() {
  const orderId = sessionStorage.getItem("orderId") || "ORD-2026-001";

  return (
    <DashboardLayout role="supplier" orderId={orderId}>
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard
            title="Dispatched"
            value="34"
            icon={Truck}
            trend="+8.2%"
            trendUp={true}
            gradient="from-blue-500 to-cyan-500"
            delay={0}
          />
          <StatsCard
            title="In Transit"
            value="18"
            icon={Clock}
            gradient="from-amber-500 to-orange-500"
            delay={0.1}
          />
          <StatsCard
            title="Delivered"
            value="142"
            icon={CheckCircle2}
            trend="+12.5%"
            trendUp={true}
            gradient="from-emerald-500 to-teal-500"
            delay={0.2}
          />
          <StatsCard
            title="Delayed"
            value="5"
            icon={AlertCircle}
            trend="-2.3%"
            trendUp={true}
            gradient="from-red-500 to-pink-500"
            delay={0.3}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Shipment Status */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              Active Shipments
            </h3>
            <div className="space-y-4">
              {shipments.map((shipment, index) => (
                <motion.div
                  key={shipment.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 + index * 0.1 }}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-white/20 transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                        <Truck className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{shipment.id}</p>
                        <p className="text-blue-200/60 text-sm">
                          {shipment.destination}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`px-3 py-1 rounded-full text-sm ${
                        shipment.status === "Delivered"
                          ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                          : shipment.status === "In Transit"
                          ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                          : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                      }`}
                    >
                      {shipment.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-blue-200/70">ETA: {shipment.eta}</span>
                    {shipment.delay && (
                      <span className="text-red-400">{shipment.delay}</span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Order Timeline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              Order Timeline
            </h3>
            <div className="space-y-6">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.6 + index * 0.1 }}
                  className="flex gap-4"
                >
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        item.status === "completed"
                          ? "bg-emerald-500"
                          : item.status === "active"
                          ? "bg-blue-500 animate-pulse"
                          : "bg-white/10 border-2 border-white/20"
                      }`}
                    >
                      {item.status === "completed" && (
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      )}
                      {item.status === "active" && (
                        <Clock className="w-5 h-5 text-white" />
                      )}
                    </div>
                    {index < timeline.length - 1 && (
                      <div
                        className={`w-0.5 h-12 ${
                          item.status === "completed"
                            ? "bg-emerald-500"
                            : "bg-white/10"
                        }`}
                      />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <p className="text-white font-medium">{item.event}</p>
                    <p className="text-blue-200/60 text-sm">{item.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Delay Tracking */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
        >
          <h3 className="text-xl font-semibold text-white mb-6">
            Delay Analysis
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30">
              <p className="text-amber-400 text-sm mb-1">Average Delay</p>
              <p className="text-2xl font-bold text-white">18 min</p>
            </div>
            <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30">
              <p className="text-blue-400 text-sm mb-1">On-Time Delivery</p>
              <p className="text-2xl font-bold text-white">94.2%</p>
            </div>
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
              <p className="text-emerald-400 text-sm mb-1">Expected Today</p>
              <p className="text-2xl font-bold text-white">12</p>
            </div>
          </div>
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
