import { motion } from "motion/react";
import DashboardLayout from "../../components/DashboardLayout";
import StatsCard from "../../components/StatsCard";
import { Package, AlertTriangle, TrendingUp, Users, Phone } from "lucide-react";
import { Button } from "../../components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const demandData = [
  { month: "Jan", value: 4000 },
  { month: "Feb", value: 3000 },
  { month: "Mar", value: 5000 },
  { month: "Apr", value: 4500 },
  { month: "May", value: 6000 },
  { month: "Jun", value: 5500 },
];

const inventoryData = [
  { product: "Electronics", stock: 450, lowStock: false },
  { product: "Clothing", stock: 23, lowStock: true },
  { product: "Food Items", stock: 890, lowStock: false },
  { product: "Medical", stock: 45, lowStock: true },
  { product: "Books", stock: 320, lowStock: false },
];

export default function WarehouseHolderDashboard() {
  const orderId = sessionStorage.getItem("orderId") || "ORD-2026-001";

  return (
    <DashboardLayout role="warehouse-holder" orderId={orderId}>
      <div className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatsCard
            title="Total Stock"
            value="1,728"
            icon={Package}
            trend="+12.5%"
            trendUp={true}
            gradient="from-blue-500 to-cyan-500"
            delay={0}
          />
          <StatsCard
            title="Low Stock Alerts"
            value="8"
            icon={AlertTriangle}
            trend="+3"
            trendUp={false}
            gradient="from-amber-500 to-orange-500"
            delay={0.1}
          />
          <StatsCard
            title="High Demand"
            value="24"
            icon={TrendingUp}
            trend="+18.2%"
            trendUp={true}
            gradient="from-emerald-500 to-teal-500"
            delay={0.2}
          />
          <StatsCard
            title="Active Orders"
            value="156"
            icon={Users}
            trend="+5.4%"
            trendUp={true}
            gradient="from-violet-500 to-purple-500"
            delay={0.3}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Inventory Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="lg:col-span-2 bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              Product Inventory
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b border-white/10">
                    <th className="pb-4 text-blue-200/70">Product</th>
                    <th className="pb-4 text-blue-200/70">Stock Level</th>
                    <th className="pb-4 text-blue-200/70">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {inventoryData.map((item, index) => (
                    <motion.tr
                      key={item.product}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: 0.5 + index * 0.1 }}
                      className="border-b border-white/5"
                    >
                      <td className="py-4 text-white">{item.product}</td>
                      <td className="py-4 text-white">{item.stock} units</td>
                      <td className="py-4">
                        <span
                          className={`px-3 py-1 rounded-full text-sm ${
                            item.lowStock
                              ? "bg-red-500/20 text-red-400 border border-red-500/30"
                              : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                          }`}
                        >
                          {item.lowStock ? "Low Stock" : "In Stock"}
                        </span>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>

          {/* Restock Suggestions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              Restock Suggestions
            </h3>
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30">
                <p className="text-amber-400 font-medium mb-1">Clothing</p>
                <p className="text-blue-200/70 text-sm">Restock: 200 units</p>
              </div>
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30">
                <p className="text-amber-400 font-medium mb-1">Medical</p>
                <p className="text-blue-200/70 text-sm">Restock: 150 units</p>
              </div>

              <div className="pt-4 space-y-3">
                <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
                  <Phone className="w-4 h-4 mr-2" />
                  Contact Supplier
                </Button>
                <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600">
                  <Phone className="w-4 h-4 mr-2" />
                  Contact Receiver
                </Button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Demand Insights Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="bg-white/5 backdrop-blur-xl rounded-2xl p-6 border border-white/10"
        >
          <h3 className="text-xl font-semibold text-white mb-6">
            Demand Insights
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={demandData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="month" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(15, 23, 42, 0.9)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "0.5rem",
                  color: "#fff",
                }}
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#3b82f6"
                strokeWidth={3}
                dot={{ fill: "#3b82f6", r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </motion.div>
      </div>
    </DashboardLayout>
  );
}
