import { motion } from "motion/react";
import { useNavigate } from "react-router";
import { useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Search, Package } from "lucide-react";

export default function OrderEntry() {
  const navigate = useNavigate();
  const [orderId, setOrderId] = useState("");
  const userRole = sessionStorage.getItem("userRole");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderId.trim()) {
      sessionStorage.setItem("orderId", orderId);
      navigate(`/dashboard/${userRole}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_0%,#000_70%,transparent_110%)]" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative w-full max-w-2xl"
      >
        {/* Icon */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex justify-center mb-8"
        >
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-500 p-4 shadow-lg shadow-blue-500/30">
            <Package className="w-full h-full text-white" />
          </div>
        </motion.div>

        {/* Glassmorphism card */}
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl p-8 md:p-12 border border-white/10 shadow-2xl">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-white mb-4">
              Enter Order ID
            </h2>
            <p className="text-blue-200/70 text-lg">
              Access your order details and tracking information
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="relative">
              <Input
                type="text"
                placeholder="e.g., ORD-2026-12345"
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
                required
                className="bg-white/5 border-white/10 text-white placeholder:text-blue-200/40 focus:border-blue-400/50 focus:ring-blue-400/20 h-14 pl-12 pr-4 text-lg"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-200/40" />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white h-14 text-lg shadow-lg shadow-blue-500/20 transition-all duration-300 hover:shadow-blue-500/40"
            >
              Access Dashboard
            </Button>
          </form>

          {/* Quick access suggestions */}
          <div className="mt-8 pt-8 border-t border-white/10">
            <p className="text-sm text-blue-200/60 text-center mb-4">
              Quick Access (Demo)
            </p>
            <div className="flex flex-wrap gap-2 justify-center">
              {["ORD-2026-001", "ORD-2026-002", "ORD-2026-003"].map((id) => (
                <button
                  key={id}
                  onClick={() => setOrderId(id)}
                  className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-blue-200/80 hover:text-blue-200 transition-all text-sm"
                >
                  {id}
                </button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
